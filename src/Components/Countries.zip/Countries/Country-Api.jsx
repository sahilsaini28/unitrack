export const countries = [
    {
        id: 1,
        name: "Australia",
        image: "./images/Australia.png",
        content: "Yes, Off course! You need a student VISA in order to gain the academics from the top notch Canadian universities. "
    },
    {
        id: 2,
        name: "United Kingdom",
        image: "./images/UK.png",
        content: "Yes, Off course! You need a student VISA in order to gain the academics from the top notch Canadian universities. "
    },
    {
        id: 3,
        name: "New Zeland",
        image: "./images/NZ.png",
        content: "Yes, Off course! You need a student VISA in order to gain the academics from the top notch Canadian universities. "
    },
    {
        id: 4,
        name: "New Zeland",
        image: "./images/NZ.png",
        content: "Yes, Off course! You need a student VISA in order to gain the academics from the top notch Canadian universities. "
    },
    // {
    //     id: 5,
    //     name: "New Zeland",
    //     image: "./images/NZ.png",
    //     content: "Yes, Off course! You need a student VISA in order to gain the academics from the top notch Canadian universities. "
    // }
]