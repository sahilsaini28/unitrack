import React from 'react'
import './CountryInner.css'

const CountryInner = ({image, content, name}) => {
  return (
    <div className='Country-Inner'>
      <img src={image} alt='Image'/>
      <h3>{name}</h3>
      <p>{content}</p>
      <button className='country-btn'>Explore More &rarr;</button>
    </div>
  )
}

export default CountryInner
